- ```javascript
  return Math.random(); 
  ```
	- {{evalparent}}