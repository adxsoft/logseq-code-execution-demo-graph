## Python code block execution
	- Note Python will load the first time this block is evaluated
	- ```python
	  var1="WORLD!"
	  def hello():
	    return "Hello " + var1
	  hello()
	  ```
		- {{evalparent}}