- Thanks to **mentaloid** on the logseq forum for this code example
	- ```python
	  import js
	  pyodide = js.logseq.Language.python.Pyodide
	  await pyodide.loadPackage("matplotlib")
	  
	  import matplotlib.pyplot as plt
	  import numpy as np
	  import io, base64
	  
	  plt.clf()
	  plt.title('title')
	  plt.xlabel('xlabel')
	  plt.ylabel('ylabel')
	  plt.grid(True)
	  
	  t = np.arange(0.0, 2.0, 0.01)
	  s = 1+np.sin(2 * np.pi * t)
	  plt.plot(t, s)
	  
	  buf = io.BytesIO()
	  plt.savefig(buf, format='png')
	  buf.seek(0)
	  png = 'data:image/png;base64,'+base64.b64encode(buf.read()).decode('UTF-8')
	  buf.close()
	  png
	  
	  ```
		- {{evalparent}}