- [Succesful API Call Tests]
	- {{query "#apicall-ok"}}
	  query-table:: true
	  query-properties:: [:block]
	  collapsed:: true
- [Failed API Call Tests]([[apicall-not-ok]])
  collapsed:: true
	- {{query "#apicall-not-ok"}}
	  query-table:: true
	  query-properties:: [:block]
- [Untested API Calls]([[apicall-untested]])
  collapsed:: true
	- {{query "#apicall-untested"}}
	  query-table:: true
	  query-properties:: [:block]
	  collapsed:: true
- [API Tests Not Relevant]([[apicall-ignore]])
	- {{query "#apicall-ignore"}}
	  query-table:: true
	  query-properties:: [:block]
	  collapsed:: true
	-