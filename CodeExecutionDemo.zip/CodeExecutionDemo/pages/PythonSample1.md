- ```javascript
  alert("PythonSample1 executed")
  ```
	- {{evalparent}}
- ```python
  import js
  js.logseq.api.show_msg("Message from page PythonSample1")
  ```
-