- ```javascript
  alert("PythonSample2 executed")
  ```
	- {{evalparent}}
- ```python
  import js
  
  js.logseq.api.show_msg("Message from page "+currentpagename)
  ```
-