- {{runpage}}
- Note
	- use of global variables to pass values between functions
	  id:: 6517c0be-4f4a-4fa0-a152-f42b5dbf7e30
	- function output accumulated into *output* variable which is displayed in the last code block to show the results of all functions executing
- ```python
  import js
  global msgno
  
  msgno=0
  def msg(text):
    global msgno
    global output
    msgno+=1
    output+=str(msgno)+' ' +text+'\n'
    
  def loadDatabase():
      global dbdict
      global output
      dbdict = {
          "Clients": {
              "ABC Co": {
                  "Address": "13 Harper St, London WC2",
                  "CEO": "Ralph Archer",
                  "Phone": "0732 12435"
              },
              "XYZ Co": {
                  "Address": "200 Finsbury Lane, London E3",
                  "CEO": "James Miller",
                  "Phone": "0726 85786"
              }
          }
      }
  
      return "Database Loaded"
  
  
  loadDatabase()
  ```
- ```python
  def getClientRecord(clientname):
      global dbdict
      try:
          clientrecord = dbdict["Clients"][clientname]
          return clientrecord
      except KeyError:
          return "FAILED"
  
  
  def testGetClientRecord(clientname, clientCEO):
      result = getClientRecord(clientname)
      try:
          if result["CEO"] == clientCEO:
              return clientname+" test PASS"
      except:
              return clientname+" test FAIL !! KEY NOT FOUND"
  
  block=js.logseq.api.get_block("6517c0be-4f4a-4fa0-a152-f42b5dbf7e30")
  # Report the output in an alert messahe
  output=""
  output+="TEST LOG FROM EXECUTION OF ALL CODE BLOCKS\n\n"
  msg(loadDatabase())
  msg(testGetClientRecord("Bad Name", ""))
  msg(testGetClientRecord("XYZ Co", "James Miller"))
  js.alert(output)
  ```