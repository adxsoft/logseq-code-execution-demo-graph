- Note use of global variables to pass values between functions
- ```python
  def loadDatabase():
      global dbdict
      dbdict = {
          "Clients": {
              "ABC Co": {
                  "Address": "13 Harper St, London WC2",
                  "CEO": "Ralph Archer",
                  "Phone": "0732 12435"
              },
              "XYZ Co": {
                  "Address": "200 Finsbury Lane, London E3",
                  "CEO": "James Miller",
                  "Phone": "0726 85786"
              }
          }
      }
  
      return "Database Loaded"
  
  
  loadDatabase()  # remove print
  ```
	- {{evalparent}}
- ```python
  def getClientRecord(clientname):
      global dbdict
      try:
          clientrecord = dbdict["Clients"][clientname]
          return clientrecord
      except KeyError:
          return "FAILED"
  
  
  def testGetClientRecord(clientname, clientCEO):
      global output
      result = getClientRecord(clientname)
      try:
          if result["CEO"] == clientCEO:
              output+=clientname+" test PASS\n"
      except:
              output+=clientname+" test FAIL !! KEY NOT FOUND\n"
  
  "Tests started"
  output=""
  testGetClientRecord("Bad Name", "")
  testGetClientRecord("XYZ Co", "James Miller")
  output
  ```
	- {{evalparent}}