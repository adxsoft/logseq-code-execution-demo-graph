#### Basic Python code block
	- template:: python code block
	  ```python
	  def sayhello():
	    return "Hello World"
	  sayhello()
	  ```
		- {{evalparent}}
- #### Basic Javascript  block
	- template:: javascript code block
	  ```javascript
	  function sayHello() {
	      return "Hello World"
	  }
	  return sayHello()
	  ```
		- {{evalparent}}