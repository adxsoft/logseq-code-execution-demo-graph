- ```python
  import js
  js.logseq.api.rename_page()
  ```
	- {{evalparent}}