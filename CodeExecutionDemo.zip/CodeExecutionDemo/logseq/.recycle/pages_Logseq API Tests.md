- #+BEGIN_NOTE
  Note Open Developer Console with **Cmd/Ctrl Shift i** and choose Console tab to see the output from a Python print statement
  #+END_NOTE
- ## Logseq API Tests
	- [[Logseq - Test API Calls from Python]]
	- ### Testing Helper Functions
		- ```python
		  def props(title,obj):
		    print("type = > "+str(obj))
		    keys=obj.object_keys()
		    vals=obj.object_values()
		    output=title+"\n"
		    for ctr in range(len(keys)):
		      output+=f"{str(keys[ctr]) : <12}  =>  {str(vals[ctr]) : <40}\n"
		    print(output)
		  ```
			- {{evalparent}}
	- ### Page Tests
		- #### Get a page
			- ```python
			  import js
			  page = js.logseq.api.get_page("Templates")
			  f"Page {page.name} found!"
			  print(props(f"Properties of {page.name}",page))
			  ```
				- {{evalparent}}
		- #### Get current page
			- ```python
			  import js
			  page=js.logseq.api.get_current_page()
			  js.alert(f"Current Page Name is '{page.name}''")
			  print(props(f"Properties of {page.name}",page))
			  ```
				- {{evalparent}}
		- #### Add a new page
		  id:: 651b8c37-6f86-4791-b804-7450101461de
			- ```python
			  import js
			  x = js.logseq.api.create_page("New Page")
			  ```
				- {{evalparent}}
		- #### Delete a page
			- ```python
			  import js
			  pagename="New Page"
			  js.logseq.api.delete_page(pagename)
			  js.alert(f"{pagename} deleted!")
			  ```
				- {{evalparent}}
		- #### Get  page by UUID
			- ```python
			  import js
			  targetpage=js.logseq.api.get_page("Templates")
			  uuid=targetpage.uuid
			  page=js.logseq.api.get_page(uuid)
			  js.alert(f"Target Page Name is '{page.name}''")
			  print(props(f"Properties of {page.name}",page))
			  ```
				- {{evalparent}}
		- #### Print current page properties to developer console
			- ```python
			  import js
			  page=js.logseq.api.get_current_page()
			  print(props(f"Properties of {page.name}",page))
			  "Done"
			  ```
				- {{evalparent}}
		- #### Print page properties of the Templates page to developer console
			- ```python
			  import js
			  page=js.logseq.api.get_page("Templates")
			  print(f"Page Name '{page.name}''")
			  print(props(f"Properties of {page.name}",page))
			  "Done"
			  ```
				- {{evalparent}}
	- ### Block Tests
		- #### Get a block UUID
		  id:: 651b866f-36c6-4b7b-a63d-6cf2508d8a8b
			- ```python
			  import js
			  block=js.logseq.api.get_current_block()
			  f"Block UUID is '{block.uuid}'"
			  ```
				- {{evalparent}}
		- #### Get a block by UUID
			- ```python
			  import js
			  block=js.logseq.api.get_current_block()
			  contents=js.logseq.api.get_editing_block_content(block.uuid)
			  sep='--------------'
			  f"Current Block UUID is {block.uuid}\n\n"+\
			  f"Block Contents\n{sep}\n{contents}\n{sep}"
			  ```
				- {{evalparent}}
		- #### Get current block content
			- ```python
			  import js
			  block=js.logseq.api.get_current_block()
			  contents=js.logseq.api.get_editing_block_content(block.uuid)
			  sep='--------------'
			  f"Current Block Contents\n{sep}\n{contents}\n{sep}"
			  ```
				- {{evalparent}}
- ## Miscellaneous Tests
	- ### Open an external web page
		- ```python
		  import js
		  js.logseq.api.open_external_link("https://www.google.com")
		  "Done"
		  ```
			- {{evalparent}}