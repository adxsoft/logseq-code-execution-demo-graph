- ```python
  import js
  print(js.logseq.api.get_block("6517c0be-4f4a-4fa0-a152-f42b5dbf7e30"))
  
  ```
	- {{evalparent}}
-